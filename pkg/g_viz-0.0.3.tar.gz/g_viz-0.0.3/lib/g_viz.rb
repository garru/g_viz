require 'set'
require 'date'
require 'erb'
require 'json'
require File.join([File.dirname(__FILE__), 'g_viz', 'g_viz'])